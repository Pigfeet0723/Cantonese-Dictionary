package com.example.activitytest;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.util.Log;
import android.widget.Toast;

import java.io.BufferedReader;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.List;

public class MyDatabaseHelper extends SQLiteOpenHelper {
    public MyDatabaseHelper(Context context, String name, SQLiteDatabase.CursorFactory factory,int version) {
        super(context, name, factory, version);
        mContext = context;
    }
    public Cursor findCharactersByCantonesePinyin(String CantonesePinyin){
        SQLiteDatabase db=getReadableDatabase();
        return db.query("character",new String[]{"simplified_Chinese_glyph","traditional_Chinese_glyph"},
                "Cantonese_pinyin==?",new String[]{CantonesePinyin},null,null,null);
    }

    public Cursor findCharactersBySimplifiedGlyph(String simplifiedGlyph){
        SQLiteDatabase db=getReadableDatabase();
        return db.query("character",new String[]{"simplified_Chinese_glyph","traditional_Chinese_glyph","Cantonese_pinyin"},
                "simplified_Chinese_glyph=?",new String[]{simplifiedGlyph},null,null,null);
    }

    public Cursor findCharacters(String initial,String nuclei,String terminal,String tone){
        SQLiteDatabase db=getReadableDatabase();
        String[] vals=new String[]{initial,nuclei,terminal,tone};
        String[] conditions=new String[]{"initial","nuclei","terminal","tone"};
        String selection= "";
        List<String> selectionArgs=new ArrayList<String>();
        for(int i=0;i<4;i++){
            if(vals[i]=="all") continue;
            if(selection.length()==0) selection+=conditions[i];
            else {
                selection+=" and ";
                selection+=conditions[i];
            }
            if(vals[i].equals("null")){
                selection += " is null ";
            }
            else{
                selection += "=?";
                selectionArgs.add(vals[i]);
            }
        }
//        return db.rawQuery("" +
//                "select simplified_Chinese_glyph,traditional_Chinese_glyph,Cantonese_pinyin\n" +
//                "from character as R,Cantonese_pinyin as S,Cantonese_pinyin_final as T\n" +
//                "where R.Cantonese_pinyin==S.pinyin and S.final==T.final and "+selection+";",selectionArgs.toArray(new String[0]));
        String sql_sentence = "" +
                "select simplified_Chinese_glyph,traditional_Chinese_glyph,Cantonese_pinyin\n" +
                "from character as R,Cantonese_pinyin as S,Cantonese_pinyin_final as T\n" +
                "where R.Cantonese_pinyin==S.pinyin and S.final==T.final ";
        if(selection != "")
            sql_sentence += "and " + selection + ";";
        else  sql_sentence += ";";
        return db.rawQuery(sql_sentence,selectionArgs.toArray(new String[0]));
    }

    public Cursor advanced_findCharacters(ArrayList<String> initial,ArrayList<String> nuclei,ArrayList<String> terminal,ArrayList<String> tone){
        SQLiteDatabase db = getReadableDatabase();
        ArrayList<String>[] vals = new ArrayList[]{initial,nuclei,terminal,tone};
        String[] conditions = new String[]{"initial","nuclei","terminal","tone"};
        String[] selection = {"", "", "", ""};
        List<String> selectionArgs = new ArrayList<String>();
        for(int i=0;i<4;i++)
        {
            if(vals[i].size() == 0) continue;
            for(int j=0;j<vals[i].size();j++)
            {
                if(selection[i].length() != 0)
                    selection[i] += " or ";
                selection[i] += conditions[i];

                if(vals[i].get(j).equals("null"))
                    selection[i] += " is null ";
                else
                {
                    selection[i] += "=?";
                    selectionArgs.add(vals[i].get(j));
                }
            }
        }
        String sql_sentence = "" +
                "select simplified_Chinese_glyph,traditional_Chinese_glyph,Cantonese_pinyin\n" +
                "from character as R,Cantonese_pinyin as S,Cantonese_pinyin_final as T\n" +
                "where R.Cantonese_pinyin==S.pinyin and S.final==T.final ";
        for(int i=0;i<4;i++)
        {
            if(selection[i] != "")
                sql_sentence += "and (" + selection[i] + ")";
        }
        sql_sentence += ";";
        return db.rawQuery(sql_sentence,selectionArgs.toArray(new String[0]));
    }


    @Override
    public void onCreate(SQLiteDatabase db){
        db.execSQL(CREATE_charactor);
        db.execSQL(CREATE_Cantonese_pinyin);
        db.execSQL(CREATE_Cantonese_pinyin_final);
        load(db);
        Toast.makeText(mContext,"Create succeeded",Toast.LENGTH_SHORT).show();
    }
    @Override
    public void onUpgrade(SQLiteDatabase db,int oldVersion,int newVersion){
    }
    private void load(SQLiteDatabase db){
        String[] arr;
        int i;

        arr=mContext.getResources().getStringArray(R.array.Cantonese_pinyin_final);
        i=0;
        while(i<arr.length){
            String final2=arr[i];
            String nuclei=arr[i+1];
            String terminal=arr[i+2];
            ContentValues values=new ContentValues();
            values.put("final",final2);
            values.put("nuclei",nuclei.equals("null")?null:nuclei);
            values.put("terminal",terminal.equals("null")?null:terminal);
            db.insert("Cantonese_pinyin_final",null,values);
            i+=3;
        }
        arr=mContext.getResources().getStringArray(R.array.Cantonese_pinyin);
        i=0;
        while(i<arr.length){
            String pinyin=arr[i];
            String initial=arr[i+1];
            String final2=arr[i+2];
            String tone=arr[i+3];
            ContentValues values=new ContentValues();
            values.put("pinyin",pinyin);
            values.put("initial",initial.equals("null")?null:initial);
            values.put("final",final2);
            values.put("tone",tone.equals("null")?null:tone);
            db.insert("Cantonese_pinyin",null,values);
            i+=4;
        }

        arr=mContext.getResources().getStringArray(R.array.character);
        i=0;
        while(i<arr.length){
            String simplified_Chinese_glyph=arr[i];
            String traditional_Chinese_glyph=arr[i+1];
            String Cantonese_pinyin=arr[i+2];
            ContentValues values=new ContentValues();
            values.put("simplified_Chinese_glyph",simplified_Chinese_glyph);
            values.put("traditional_Chinese_glyph",traditional_Chinese_glyph);
            values.put("Cantonese_pinyin",Cantonese_pinyin);
            db.insert("character",null,values);
            i+=3;
        }
    }
    private void readIntoDatabase(SQLiteDatabase db,String line){
        String simplified_Chinese_glyph,traditional_Chinese_glyph,Cantonese_pinyin;
        int index=0;
        ReadWordResult res;
        res=readWord(line,index);
        simplified_Chinese_glyph=res.word;
        index=res.end;
        res=readWord(line,index);
        traditional_Chinese_glyph=res.word;
        index=res.end;
        res=readWord(line,index);
        Cantonese_pinyin=res.word;
        index=res.end;
        ContentValues values=new ContentValues();
        values.put("simplified_Chinese_glyph",simplified_Chinese_glyph);
        values.put("traditional_Chinese_glyph",traditional_Chinese_glyph);
        values.put("Cantonese_pinyin",Cantonese_pinyin);
        db.insert("character",null,values);
    }
    private static final class ReadWordResult{
        public int end;
        public String word;
    }
    private ReadWordResult readWord(String str,int start){
        ReadWordResult res=new ReadWordResult();
        int i=start;
        while(i<str.length()){
            if(str.charAt(i)!=' ') break;
            else i++;
        }
        res.word="";
        while(i<str.length()){
            if(str.charAt(i)==' ') break;
            res.word+=str.charAt(i);
            i++;
        }
        res.end=i;
        return res;
    }
    private Context mContext;
    private static final String  CREATE_charactor= "create table character("+
            "simplified_Chinese_glyph text,"+
            "traditional_Chinese_glyph text,"+
            "Cantonese_pinyin text," +
            "primary key(simplified_Chinese_glyph,traditional_Chinese_glyph,Cantonese_pinyin)," +
            "foreign key (Cantonese_pinyin) references Cantonese_pinyin);";
    private static final String CREATE_Cantonese_pinyin="create table Cantonese_pinyin(" +
            "pinyin text primary key," +
            "initial text," +
            "final text," +
            "tone text," +
            "foreign key (final) references Cantonese_pinyin_final);";
    private static final String CREATE_Cantonese_pinyin_final="create table Cantonese_pinyin_final(" +
            "final text primary key," +
            "nuclei text," +
            "terminal text);";
}