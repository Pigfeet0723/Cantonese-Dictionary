package com.example.activitytest

import android.app.AlertDialog
import android.content.DialogInterface
import android.content.DialogInterface.OnMultiChoiceClickListener
import android.content.Intent
import android.os.Bundle
import android.view.Menu
import android.view.MenuItem
import android.widget.ArrayAdapter
import android.widget.Button
import android.widget.ListView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity


class ThirdActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.third_layout)
        var dbhelper = MyDatabaseHelper(this, "Dictionary.db", null, 1)
        dbhelper.readableDatabase//初始化dbhelper
        val searchButton: Button = findViewById(R.id.searchbutton)//搜索按钮

        //声母的下拉菜单
        val btnShengmu: Button =findViewById(R.id.buttonshengmu)
        val textShengmu=ArrayList<String>()
        btnShengmu.setOnClickListener{
            val mItemsShengmu=resources.getTextArray(R.array.multishengmu)//声母对应的字符串初始化
            textShengmu.clear()
            AlertDialog.Builder(this)
                .setTitle("声母")
                .setMultiChoiceItems(mItemsShengmu,BooleanArray(mItemsShengmu.size){false},DialogInterface.OnMultiChoiceClickListener { dialogInterface,i,chosen ->
                    if(chosen)
                    {
                        if(mItemsShengmu[i].toString()=="无")
                            textShengmu.add("null")
                        else
                            textShengmu.add(mItemsShengmu[i].toString())
                    }
                    else
                    {
                        if(mItemsShengmu[i].toString()=="无")
                            textShengmu.remove("null")
                        else
                            textShengmu.remove(mItemsShengmu[i].toString())
                    }
//                    Toast.makeText(this,textShengmu[0],Toast.LENGTH_SHORT).show()
                })
                .setPositiveButton("确定", DialogInterface.OnClickListener { _, _ ->
                    Toast.makeText(this,"声母设置成功",Toast.LENGTH_LONG).show()
                })
                .setNegativeButton("取消", DialogInterface.OnClickListener { _, _ ->
                    textShengmu.clear()
                })
                .create()
                .show()
        }

        val btnYunfu: Button =findViewById(R.id.buttonyunfu)
        val textYunfu=ArrayList<String>()
        btnYunfu.setOnClickListener{
            val mItemsYunfu=resources.getTextArray(R.array.multiyunfu)//对应的字符串初始化
            textYunfu.clear()
            AlertDialog.Builder(this)
                .setTitle("韵腹")
                .setMultiChoiceItems(mItemsYunfu,BooleanArray(mItemsYunfu.size){false},DialogInterface.OnMultiChoiceClickListener { dialogInterface,i,chosen ->
                    if(chosen)
                    {
                        if(mItemsYunfu[i].toString()=="无")
                            textYunfu.add("null")
                        else
                            textYunfu.add(mItemsYunfu[i].toString())
                    }
                    else
                    {
                        if(mItemsYunfu[i].toString()=="无")
                            textYunfu.remove("null")
                        else
                            textYunfu.remove(mItemsYunfu[i].toString())
                    }
                    //Toast.makeText(this,textYunfu[textYunfu.size-1],Toast.LENGTH_SHORT).show()
                })
                .setPositiveButton("确定", DialogInterface.OnClickListener { _, _ ->
                    Toast.makeText(this,"韵腹设置成功",Toast.LENGTH_LONG).show()
                })
                .setNegativeButton("取消", DialogInterface.OnClickListener { _, _ ->
                    textYunfu.clear()
                })
                .create()
                .show()
        }
        val btnYunwei: Button =findViewById(R.id.buttonyunwei)
        val textYunwei=ArrayList<String>()
        btnYunwei.setOnClickListener{
            val mItemsYunwei=resources.getTextArray(R.array.multiyunwei)//对应的字符串初始化
            textYunwei.clear()
            AlertDialog.Builder(this)
                .setTitle("韵尾")
                .setMultiChoiceItems(mItemsYunwei,BooleanArray(mItemsYunwei.size){false},DialogInterface.OnMultiChoiceClickListener { dialogInterface,i,chosen ->
                    if(chosen)
                    {
                        if(mItemsYunwei[i].toString()=="无")
                            textYunwei.add("null")
                        else
                            textYunwei.add(mItemsYunwei[i].toString())
                    }
                    else
                    {
                        if(mItemsYunwei[i].toString()=="无")
                            textYunwei.remove("null")
                        else
                            textYunwei.remove(mItemsYunwei[i].toString())
                    }
                    //Toast.makeText(this,textYunwei[textYunwei.size-1],Toast.LENGTH_SHORT).show()
                })
                .setPositiveButton("确定", DialogInterface.OnClickListener { _, _ ->
                    Toast.makeText(this,"韵尾设置成功",Toast.LENGTH_LONG).show()
                })
                .setNegativeButton("取消", DialogInterface.OnClickListener { _, _ ->
                    textYunwei.clear()
                })
                .create()
                .show()
        }
        val btnYindiao: Button =findViewById(R.id.buttonyindiao)
        val textYindiao=ArrayList<String>()
        btnYindiao.setOnClickListener{
            val mItemsYindiao=resources.getTextArray(R.array.multiyindiao)//对应的字符串初始化
            textYindiao.clear()
            AlertDialog.Builder(this)
                .setTitle("音调")
                .setMultiChoiceItems(mItemsYindiao,BooleanArray(mItemsYindiao.size){false},DialogInterface.OnMultiChoiceClickListener { dialogInterface,i,chosen ->
                    if(chosen)
                    {
                        if(mItemsYindiao[i].toString()=="无")
                            textYindiao.add("null")
                        else
                            textYindiao.add(mItemsYindiao[i].toString())
                    }
                    else
                    {
                        if(mItemsYindiao[i].toString()=="无")
                            textYindiao.remove("null")
                        else
                            textYindiao.remove(mItemsYindiao[i].toString())
                    }
                    //Toast.makeText(this,textYindiao[textYindiao.size-1],Toast.LENGTH_SHORT).show()
                })
                .setPositiveButton("确定", DialogInterface.OnClickListener { _, _ ->
                    Toast.makeText(this,"音调设置成功",Toast.LENGTH_LONG).show()
                })
                .setNegativeButton("取消", DialogInterface.OnClickListener { _, _ ->
                    textYindiao.clear()
                })
                .create()
                .show()
        }
        searchButton.setOnClickListener{
            val textOutput: ListView =findViewById(R.id.listView)
            val result = dbhelper.advanced_findCharacters(textShengmu,textYunfu,textYunwei,textYindiao)
            var output = ArrayList<String>()//输出的结果

            if(result.moveToFirst())
            {
                do
                {
                    var c1 = result.getString(result.getColumnIndex("simplified_Chinese_glyph"))//简体字
                    val c2 = result.getString(result.getColumnIndex("traditional_Chinese_glyph"))//繁体字
                    val c3 = result.getString(result.getColumnIndex("Cantonese_pinyin"))//拼音
                    output.add(c1+"("+c2+")"+c3+"\n")//每次累计输出字符串
                }while (result.moveToNext())
            }
            result.close()
            val aaOutput = ArrayAdapter(this, android.R.layout.simple_list_item_1, output)
            textOutput.setAdapter(aaOutput)
        }
    }

    // 允许菜单显示
    override fun onCreateOptionsMenu(menu: Menu?): Boolean {
        menuInflater.inflate(R.menu.main, menu)
        return true
    }

    // 对菜单中选择的选项进行操作
    override fun onOptionsItemSelected(item: MenuItem): Boolean {
        when(item.itemId)
        {
            R.id.index1 -> {
                //Toast.makeText(this, "You clicked Add", Toast.LENGTH_SHORT).show()
                val intent = Intent(this,FirstActivity::class.java)
                startActivity(intent)
            }
            R.id.index2 -> {
                //Toast.makeText(this, "You clicked Add", Toast.LENGTH_SHORT).show()
                val intent = Intent(this,SecondActivity::class.java)
                startActivity(intent)
            }
            R.id.index3 -> Toast.makeText(this, "您已经位于高级检索页面！", Toast.LENGTH_SHORT).show()
        }
        return true
    }
}