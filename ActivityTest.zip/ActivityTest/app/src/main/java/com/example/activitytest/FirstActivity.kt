package com.example.activitytest

import android.content.Intent
import android.os.Bundle
import android.util.Log
import android.view.Menu
import android.view.MenuItem
import android.view.View
import android.widget.*
import android.widget.AdapterView.OnItemSelectedListener
import androidx.appcompat.app.AppCompatActivity


class FirstActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.first_layout)
        var dbhelper = MyDatabaseHelper(this, "Dictionary.db", null, 1)
        dbhelper.readableDatabase//初始化dbhelper
        val searchButton: Button = findViewById(R.id.searchbutton)//搜索按钮

        //声母的下拉菜单
        val spinnerShengmu:Spinner=findViewById(R.id.spinnershengmu)
        val  mItemsShengmu=resources.getStringArray(R.array.shengmu)//声母对应的字符串初始化
        val aaShengmu = ArrayAdapter(this, android.R.layout.simple_spinner_item, mItemsShengmu)
        aaShengmu.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item)
        var textShengmu=""
        spinnerShengmu.setOnItemSelectedListener(object : OnItemSelectedListener {
            override fun onItemSelected(//重载选定监听器
                arg0: AdapterView<*>?, arg1: View?, arg2: Int, arg3: Long) {
                textShengmu=mItemsShengmu.get(arg2) //取选定的字符串
                if(textShengmu==mItemsShengmu[0]) textShengmu="all"
                else if(textShengmu=="无") textShengmu="null"
            }
            override fun onNothingSelected(arg0: AdapterView<*>?) {textShengmu="all"}
        })
        spinnerShengmu.setAdapter(aaShengmu)

        //韵腹的下拉菜单
        val spinnerYunfu:Spinner=findViewById(R.id.spinneryunfu)
        val  mItemsYunfu=resources.getStringArray(R.array.yunfu)
        val aaYunfu = ArrayAdapter(this, android.R.layout.simple_spinner_item, mItemsYunfu)
        aaYunfu.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item)
        var textYunfu=""
        spinnerYunfu.setOnItemSelectedListener(object : OnItemSelectedListener {
            override fun onItemSelected(
                arg0: AdapterView<*>?, arg1: View?, arg2: Int, arg3: Long) {
                textYunfu=mItemsYunfu.get(arg2) //toast(arg0.getSelectedItem().toString());
                if(textYunfu==mItemsYunfu[0]) textYunfu="all"
                else if(textYunfu=="无") textYunfu="null"
            }
            override fun onNothingSelected(arg0: AdapterView<*>?) {textYunfu="all"}
        })
        spinnerYunfu.setAdapter(aaYunfu)

        //韵尾的下拉菜单
        val spinnerYunwei:Spinner=findViewById(R.id.spinneryunwei)
        val  mItemsYunwei=resources.getStringArray(R.array.yunwei)
        val aaYunwei = ArrayAdapter(this, android.R.layout.simple_spinner_item, mItemsYunwei)
        aaYunwei.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item)
        var textYunwei=""
        spinnerYunwei.setOnItemSelectedListener(object : OnItemSelectedListener {
            override fun onItemSelected(
                arg0: AdapterView<*>?, arg1: View?, arg2: Int, arg3: Long) {
                textYunwei=mItemsYunwei.get(arg2) //toast(arg0.getSelectedItem().toString());
                if(textYunwei==mItemsYunwei[0]) textYunwei="all"
                else if(textYunwei=="无") textYunwei="null"
            }
            override fun onNothingSelected(arg0: AdapterView<*>?) {textYunwei="all"}
        })
        spinnerYunwei.setAdapter(aaYunwei)

        //音调的下拉菜单
        val spinnerYindiao:Spinner=findViewById(R.id.spinneryindiao)
        val  mItemsYindiao=resources.getStringArray(R.array.yindiao)
        val aaYindiao = ArrayAdapter(this, android.R.layout.simple_spinner_item, mItemsYindiao)
        aaYindiao.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item)
        var textYindiao=""
        spinnerYindiao.setOnItemSelectedListener(object : OnItemSelectedListener {
            override fun onItemSelected(
                arg0: AdapterView<*>?, arg1: View?, arg2: Int, arg3: Long) {
                textYindiao=mItemsYindiao.get(arg2) //toast(arg0.getSelectedItem().toString());
                if(textYindiao==mItemsYindiao[0]) textYindiao="all"
                else if(textYindiao=="无") textYindiao="null"
            }
            override fun onNothingSelected(arg0: AdapterView<*>?) {textYindiao="all"}
        })
        spinnerYindiao.setAdapter(aaYindiao)

        //重载点击搜索按钮的监听器
        searchButton.setOnClickListener{
            var tempText=textShengmu+textYunfu+textYunwei+textYindiao
            val textOutput:ListView=findViewById(R.id.listView)
//            Toast.makeText(this,tempText,Toast.LENGTH_SHORT).show()
            val result = dbhelper.findCharacters(textShengmu,textYunfu,textYunwei,textYindiao)
            var output = ArrayList<String>()//输出的结果
//            if(textShengmu=="all"&&textYunfu=="all"&&textYunwei=="all"&&textYindiao=="all")
//            {
////                Toast.makeText(this,tempText,Toast.LENGTH_SHORT).show()
//                return@setOnClickListener
//            }
            if(result.moveToFirst())
            {
                do
                {
                    var c1 = result.getString(result.getColumnIndex("simplified_Chinese_glyph"))//简体字
                    val c2 = result.getString(result.getColumnIndex("traditional_Chinese_glyph"))//繁体字
                    val c3 = result.getString(result.getColumnIndex("Cantonese_pinyin"))//拼音
                    output.add(c1+"("+c2+")"+c3+"\n")//每次累计输出字符串
//                    Log.d("FirstActivity", output[cnt])
//                    Log.d("FirstActivity", "$cnt")
//                    cnt += 1
                    //Toast.makeText(this,output,Toast.LENGTH_SHORT).show()
                }while (result.moveToNext())
            }
            result.close()
            val aaOutput = ArrayAdapter(this, android.R.layout.simple_list_item_1, output)
            textOutput.setAdapter(aaOutput)
        }
    }

    // 允许菜单显示
    override fun onCreateOptionsMenu(menu: Menu?): Boolean {
        menuInflater.inflate(R.menu.main, menu)
        return true
    }

    // 对菜单中选择的选项进行操作
    override fun onOptionsItemSelected(item: MenuItem): Boolean {
        when(item.itemId)
        {
            R.id.index1 -> Toast.makeText(this, "您已经位于粤拼检索页面！", Toast.LENGTH_SHORT).show()
            R.id.index2 -> {
                //Toast.makeText(this, "You clicked Add", Toast.LENGTH_SHORT).show()
                val intent = Intent(this,SecondActivity::class.java)
                startActivity(intent)
            }
            R.id.index3 -> {
                //Toast.makeText(this, "You clicked Add", Toast.LENGTH_SHORT).show()
                val intent = Intent(this,ThirdActivity::class.java)
                startActivity(intent)
            }
        }
        return true
    }
}