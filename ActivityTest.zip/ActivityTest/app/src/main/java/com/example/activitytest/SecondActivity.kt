package com.example.activitytest

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.Menu
import android.view.MenuItem
import android.widget.*

class SecondActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.second_layout)
        var dbhelper = MyDatabaseHelper(this, "Dictionary.db", null, 1)
        dbhelper.readableDatabase//初始化dbhelper
        val searchButton: Button = findViewById(R.id.searchbutton)//搜索按钮
        val editText:EditText=findViewById(R.id.edittext)
        searchButton.setOnClickListener{
            var output = ArrayList<String>()//输出的结果
            var tempText=editText.text.toString()
            val textOutput: ListView =findViewById(R.id.listView)
            //Toast.makeText(this,tempText,Toast.LENGTH_SHORT).show()
            for(i in tempText)
            {
                val result = dbhelper.findCharactersBySimplifiedGlyph(i.toString())
                if(result.moveToFirst())
                {
                    do
                    {
                        var c1 = result.getString(result.getColumnIndex("simplified_Chinese_glyph"))//简体字
                        val c2 = result.getString(result.getColumnIndex("traditional_Chinese_glyph"))//繁体字
                        val c3 = result.getString(result.getColumnIndex("Cantonese_pinyin"))//拼音
                        output.add(c1+"("+c2+")"+c3+"\n")//每次累计输出字符串
//                    Log.d("FirstActivity", output[cnt])
//                    Log.d("FirstActivity", "$cnt")
//                    cnt += 1
                        //Toast.makeText(this,output,Toast.LENGTH_SHORT).show()
                    }while (result.moveToNext())
                }
                result.close()
            }
            val aaOutput = ArrayAdapter(this, android.R.layout.simple_list_item_1, output)
            textOutput.setAdapter(aaOutput)
        }

    }



    // 允许菜单显示
    override fun onCreateOptionsMenu(menu: Menu?): Boolean {
        menuInflater.inflate(R.menu.main, menu)
        return true
    }

    // 对菜单中选择的选项进行操作
    override fun onOptionsItemSelected(item: MenuItem): Boolean {
        when(item.itemId)
        {
            R.id.index1 -> {
                val intent = Intent(this,FirstActivity::class.java)
                startActivity(intent)
            }
            R.id.index2 -> {
                //Toast.makeText(this, "You clicked Add", Toast.LENGTH_SHORT).show()
                Toast.makeText(this, "您已经位于简字检索页面！", Toast.LENGTH_SHORT).show()
            }
            R.id.index3 -> {
                //Toast.makeText(this, "You clicked Add", Toast.LENGTH_SHORT).show()
                val intent = Intent(this,ThirdActivity::class.java)
                startActivity(intent)
            }

        }
        return true
    }
}