package com.example.activitytest

import android.app.ActionBar
import android.content.Intent
import android.os.Bundle
import android.widget.Button
import androidx.appcompat.app.AppCompatActivity

class MainActivity : AppCompatActivity() {
    var dbHelper= MyDatabaseHelper(this, "Dictionary.db", null, 1)
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.main_layout)
        dbHelper.writableDatabase
        val actionBar: androidx.appcompat.app.ActionBar? = supportActionBar
        if(actionBar != null ){
            actionBar.hide();
        }

        val btn: Button = findViewById(R.id.button)
        btn.setOnClickListener {
            val intent = Intent(this, FirstActivity::class.java)
            startActivity(intent)
        }

    }
}